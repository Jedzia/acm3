
A small PNG to C64 multicolor bitmap converter.

By Mix256.

Creates a C64 runnable prg file from a 320x200x4 png file.
Best used with peptos palette.

Useage: PNG2PRG [INFILE] [OUTFILE] [BKG_COL]
Where BKG_COL is in the range 0 to 15 specifying the background color of the picture.

Example: PNG2PRG test.png test.prg 0

